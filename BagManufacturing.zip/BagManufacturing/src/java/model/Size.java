/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import databaseconnection.PGSQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author hariv
 */
public class Size {
    private int id;
    private double length;
    private double width;
    private double height;
    private String designation;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Size(int id, double length, double width, double height, String designation) {
        this.setId(id);
        this.setLength(length);
        this.setWidth(width);
        this.setHeight(height);
        this.setDesignation(designation);
    }

    public Size() {
    }

    public static Size getById(int id) throws Exception {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Size size = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT id, length, width, height, designation FROM size WHERE id = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                size = new Size();
                size.setId(resultSet.getInt("id"));
                size.setLength(resultSet.getDouble("length"));
                size.setWidth(resultSet.getDouble("width"));
                size.setHeight(resultSet.getDouble("height"));
                size.setDesignation(resultSet.getString("designation"));
            }
        } finally {
            // Close resources in a finally block
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        return size;
    }
}
