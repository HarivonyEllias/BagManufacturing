/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import databaseconnection.PGSQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hariv
 */
public class Product {
    private int id;
    private Article article;
    private int componentRef;
    private Type type;
    private Timestamp beginDate;
    private Timestamp endDate;
    private Size size;

    public Size getSize() {
        return size;
    }

    public void setSize(Size size) {
        this.size = size;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Article getArticle() {
        return article;
    }

    public void setArticle(Article article) {
        this.article = article;
    }

    public int getComponentRef() {
        return componentRef;
    }

    public void setComponentRef(int componentRef) {
        this.componentRef = componentRef;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Timestamp getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Timestamp beginDate) {
        this.beginDate = beginDate;
    }
    
    public void setBeginDate(String beginDate) {
        this.beginDate = Product.convertToTimestamp(beginDate);
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }
    
    public void setEndDate(String endDate) {
        this.endDate = Product.convertToTimestamp(endDate);
    }

    public double getManufacturingDuration(){
        return (this.getEndDate().getTime() - this.getBeginDate().getTime())/(1000*60*60);//in term of hours
    }
    
    public String getFormattedComposants(){
        Component c = new Component(this.getComponentRef());
        c.init_materials();
        Material[] materials = c.init_materials();
        String formattedMaterials = "";
        int i = 0;
        for(Material m : materials){
            String regex = (materials.length-1==i)?"":", ";
            formattedMaterials += m.getName()+regex;
            i++;
        }
        return formattedMaterials;
    }
    
    public Material[] getComposants(){
        Component c = new Component(this.getComponentRef());
        Material[] materials = c.init_materials();
        return materials;
    }
    
    public String getFormattedLooks(){
        Component c = new Component(this.getComponentRef());
        Material[] materials = c.init_materials();
        String formattedMaterials = "";
        int i = 0;
        for(Material m : materials){
            String regex = (materials.length-1==i)?"":", ";
            if(m.getLook()!=null)
            formattedMaterials += m.getLook().getName()+regex;
            i++;
        }
        return formattedMaterials;
    }
    
    public Product(int id, Article article, int componentRef, Type type, Timestamp beginDate, Timestamp endDate) {
        this.setId(id);
        this.setArticle(article);
        this.setComponentRef(componentRef);
        this.setType(type);
        this.setBeginDate(beginDate);
        this.setEndDate(endDate);
    }

    public Product() {
    }

//    FUNCTIONS
    public void saveSize(){
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "insert into size(idproduct,length,width,height,designation) values (?,?,?,?,?)";
            statement = connection.prepareStatement(query);
            statement.setInt(1, this.getId());
            statement.setDouble(2,this.getSize().getLength());
            statement.setDouble(3,this.getSize().getWidth());
            statement.setDouble(4,this.getSize().getHeight());
            statement.setString(5,this.getSize().getDesignation());

            statement.executeUpdate();
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    
    public Product[] filter(int[] idmaterials,Product[] products){
        List<Product> liste_product = new ArrayList<>();
        for(Product p : products){
            for(int idmaterial : idmaterials){
                Material[] composants = p.getComposants();
                for(Material m : composants){
                    if(m.getId()==idmaterial)
                        liste_product.add(p);
               }
            }
        }
        return liste_product.toArray(new Product[liste_product.size()]);
    }
    
    public static Timestamp convertToTimestamp(String dateString) {
        Timestamp timestamp = null;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            java.util.Date parsedDate = dateFormat.parse(dateString);
            timestamp = new Timestamp(parsedDate.getTime());
        } catch (Exception e) {
            e.printStackTrace(); // Handle the parsing exception according to your application needs
        }
        return timestamp;
    }
    public static int getnextId(){
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT max(id)+1 id FROM product";
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
               return resultSet.getInt("id");
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            // Close resources in a finally block
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return -1;
    }
    public void saveComposant(int ref,Connection connection) throws Exception {
        boolean t = false;
        if(connection == null){
            try {
                connection=PGSQLConnection.getConnection();
                t=true;
            } catch (SQLException ex) {
                throw ex;
            }
        }
        PreparedStatement statement = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "INSERT INTO product_composant(idproduct,composantref) values (?,?)";
            statement = connection.prepareStatement(query);
            statement.setInt(1, this.getId());
            statement.setInt(2, ref);
            statement.executeQuery();
        } finally {
            if(t==true){
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }
    
//    CRUD FUNCTIONS
    public void create(Connection connection)throws Exception{
        boolean t = false;
        if(connection == null){
            try {
                connection=PGSQLConnection.getConnection();
                t=true;
            } catch (SQLException ex) {
                Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        PreparedStatement statement = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "INSERT INTO product(idarticle,composantref,idtype,begindate,endingdate) VALUES(?,?,?,?,?)";
            statement = connection.prepareStatement(query);
            statement.setInt(1, this.getArticle().getId());
            statement.setInt(2, this.getComponentRef());
            statement.setInt(3, this.getType().getId());
            statement.setTimestamp(4, this.getBeginDate());            
            statement.setTimestamp(5, this.getEndDate());

            statement.executeUpdate();

            
        } finally {
            if(t==true){
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }
    public static Product getById(int id) throws Exception {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Product product = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT id, idarticle, composantref, idtype, begindate, endingdate FROM product WHERE id = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                product = new Product();
                product.setId(resultSet.getInt("id"));
                product.setArticle(Article.getById(resultSet.getInt("idarticle")));
                product.setComponentRef(resultSet.getInt("composantref"));
                product.setType(Type.getById(resultSet.getInt("idtype")));
                product.setBeginDate(resultSet.getTimestamp("begindate"));
                product.setEndDate(resultSet.getTimestamp("endingdate"));
            }
        } finally {
            // Close resources in a finally block
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        return product;
    }
    
    public static Product[] getAll(Connection connection) throws Exception {
        boolean t = false;
        if(connection == null){
            connection = PGSQLConnection.getConnection();
            t = true;
        }
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Product> products = new ArrayList<>();

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT id, idarticle, composantref, idtype, begindate, endingdate FROM product";
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Product product = new Product();
                product.setId(resultSet.getInt("id"));
                product.setArticle(Article.getById(resultSet.getInt("idarticle")));
                product.setComponentRef(resultSet.getInt("composantref"));
                product.setType(Type.getById(resultSet.getInt("idtype")));
                product.setBeginDate(resultSet.getTimestamp("begindate"));
                product.setEndDate(resultSet.getTimestamp("endingdate"));
                products.add(product);
            }
            
            return products.toArray(new Product[products.size()]);
        } finally {
            if(t==true){
                // Close resources in a finally block
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            }
        }
    }
}