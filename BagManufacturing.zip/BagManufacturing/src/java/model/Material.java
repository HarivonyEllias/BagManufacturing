package model;

import databaseconnection.PGSQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Material {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Material(int id, String name) {
        this.setId(id);
        this.setName(name);
    }

    public Material() {
    }

//    FUNCTIONS
    public void savePrice(Connection connection,double price)throws Exception{
        boolean t = false;
        if(connection == null){
            connection = PGSQLConnection.getConnection();
            t = true;
        }
        PreparedStatement statement = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "insert into matiere_prix(idmatierial,prix) values (?,?)";
            statement = connection.prepareStatement(query);
            statement.setInt(1, this.getId());
            statement.setDouble(2,price);
            statement.executeUpdate();
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            if(t==true){
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
    }
    public void saveLook(int idlook){
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "insert into matiere_look(idmatierial,idlook) values (?,?)";
            statement = connection.prepareStatement(query);
            statement.setInt(1, this.getId());
            statement.setInt(2,idlook);
            statement.executeUpdate();
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    public Look getLook(){
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT idlook FROM matiere_look where idmatierial = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, this.getId());
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
               return Look.getById(resultSet.getInt("idlook"));
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            // Close resources in a finally block
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return null;
    }

    public void create() throws Exception{
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "insert into matierial(name) values (?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, this.getName());
            statement.executeUpdate();
        }catch (Exception ex){
            ex.printStackTrace();
            throw ex;
        }finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    public static int getnextRef(){
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT max(ref)+1 newref FROM composant";
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
               return resultSet.getInt("newref");
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            // Close resources in a finally block
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return -1;
    }
    public static int createComposants(Material[] materials ,Connection connection) throws Exception{
        boolean t = false;
        if(connection == null){
            try {
                connection=PGSQLConnection.getConnection();
                t=true;
            } catch (SQLException ex) {
                Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        PreparedStatement statement = null;

        try {
            connection = PGSQLConnection.getConnection();
            int ref = getnextRef();
            if(ref<0)throw new Exception("negative ref");
            String query = "INSERT INTO composant(ref,idmatierial) values (?,?)";
            for(Material material : materials){
                statement = connection.prepareStatement(query);
                statement.setInt(1, ref);
                statement.setInt(2, material.getId());
                statement.executeUpdate();
            }
            return ref;
        } catch (Exception ex){
           throw ex;
        }finally {
            if(t==true){
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }
    
//    CRUD FUNCTIONS
     public static Material getById(int id) throws Exception {
         Connection connection = null;
         PreparedStatement statement = null;
         ResultSet resultSet = null;
        Material material = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT id, name FROM matierial WHERE id = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                material = new Material();
                material.setId(resultSet.getInt("id"));
                material.setName(resultSet.getString("name"));
            }
        } finally {
            // Close resources in a finally block
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        return material;
    }
     public static Material[] getAll(Connection connection) throws Exception {
         boolean t = false;
         if(connection == null){
             connection = PGSQLConnection.getConnection();
             t = true;
         }
         PreparedStatement statement = null;
         ResultSet resultSet = null;
         List<Material> Materials= new ArrayList<>();

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT id, name FROM matierial";
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while(resultSet.next()) {
                Material a= new Material();
                a.setId(resultSet.getInt("id"));
                a.setName(resultSet.getString("name"));
                Materials.add(a);
            }
        } finally {
            if(t==true){
                // Close resources in a finally block
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            }
        }

        return Materials.toArray(new Material[Materials.size()]);
    }
}
