package model;

import databaseconnection.PGSQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Look {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Look(int id, String name) {
        this.setId(id);
        this.setName(name);
    }

    public Look() {
    }

    public void create(){
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "insert into look (name) values (?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, this.getName());
            statement.executeQuery();
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public static Look getById(int id) throws Exception {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        Look Look = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT id, name FROM look WHERE id = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Look = new Look();
                Look.setId(resultSet.getInt("id"));
                Look.setName(resultSet.getString("name"));
            }
        } finally {
            // Close resources in a finally block
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        return Look;
    }
    
    public static Look[] getAll(Connection connection) throws Exception {
         boolean t = false;
         if(connection == null){
             connection = PGSQLConnection.getConnection();
             t = true;
         }
         PreparedStatement statement = null;
         ResultSet resultSet = null;
         List<Look> articles= new ArrayList<>();

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT id, name FROM look";
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while(resultSet.next()) {
                Look a= new Look();
                a.setId(resultSet.getInt("id"));
                a.setName(resultSet.getString("name"));
                articles.add(a);
            }
        } finally {
            if(t==true){
                // Close resources in a finally block
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            }
        }

        return articles.toArray(new Look[articles.size()]);
    }
}
