/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import databaseconnection.PGSQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author hariv
 */
public class Component {
    private int id;
    private int ref;
    private Material[] materials;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRef() {
        return ref;
    }

    public void setRef(int ref) {
        this.ref = ref;
    }

    public Material[] getMaterials() {
        return materials;
    }

    public void setMaterials(Material[] material) {
        this.materials = materials;
    }

    public Component(int id, int ref) {
        this.setId(id);
        this.setRef(ref);
    }
    public Component(int ref) {
        this.setRef(ref);
        this.init_materials();
    }

    public Component() {
    }
    
//    FUNCTIONS
    public Material[] init_materials(){
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Material> materialsL = new ArrayList<>();
        
        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT idmatierial FROM composant WHERE ref = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, this.getRef());
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                materialsL.add(
                    Material.getById(resultSet.getInt("idmatierial"))
//                        Material.getById(1)
                );
            }
            this.setMaterials(materialsL.toArray(new Material[materialsL.size()]));
            return materialsL.toArray(new Material[materialsL.size()]);
        } catch(Exception e){
            e.printStackTrace();
        } finally {
            // Close resources in a finally block
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
        return null;
    }
    
}
