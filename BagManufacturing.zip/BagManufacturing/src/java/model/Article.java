/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import databaseconnection.PGSQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hariv
 */
public class Article {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Article(int id, String name) {
        this.setId(id);
        this.setName(name);
    }

    public Article() {
    }

    public void create(){
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "insert into article (name) values (?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, this.getName());
            statement.executeQuery();
        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Material.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public static Article getById(int id) throws Exception {
         Connection connection = null;
         PreparedStatement statement = null;
         ResultSet resultSet = null;
        Article Article = null;

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT id, name FROM article WHERE id = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Article = new Article();
                Article.setId(resultSet.getInt("id"));
                Article.setName(resultSet.getString("name"));
            }
        } finally {
            // Close resources in a finally block
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        return Article;
    }
    
    public static Article[] getAll(Connection connection) throws Exception {
         boolean t = false;
         if(connection == null){
             connection = PGSQLConnection.getConnection();
             t = true;
         }
         PreparedStatement statement = null;
         ResultSet resultSet = null;
         List<Article> articles= new ArrayList<>();

        try {
            connection = PGSQLConnection.getConnection();
            String query = "SELECT id, name FROM article";
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while(resultSet.next()) {
                Article a= new Article();
                a.setId(resultSet.getInt("id"));
                a.setName(resultSet.getString("name"));
                articles.add(a);
            }
        } finally {
            if(t==true){
                // Close resources in a finally block
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            }
        }

        return articles.toArray(new Article[articles.size()]);
    }
}