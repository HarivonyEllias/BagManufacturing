package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Article;
import model.Look;
import model.Material;
import model.Product;
import model.Size;
import model.Type;

public class AddNameController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        try{
         
        String identifier = request.getParameter("identifier");
        String name = request.getParameter("name");
        switch (identifier) {
            case "material":
                Material m = new Material();
                m.setName(name);
                m.create();
                break;
            case "look":
                Look l = new Look();
                l.setName(name);
                l.create();
                break;
            case "type":
                Type t = new Type();
                t.setName(name);
                t.create();
                break;
            case "article":
                Article a = new Article();
                a.setName(name);
                a.create();
                response.getWriter().println(name);
                break;
            case "material_look":
                int idmaterial = Integer.parseInt(request.getParameter("material"));
                int idlook = Integer.parseInt(request.getParameter("look"));
                Material.getById(idmaterial).saveLook(idlook);
                break;
            case "product_size":
                int idproduct = Integer.parseInt(request.getParameter("product"));
                double length = Double.parseDouble(request.getParameter("length"));
                double width = Double.parseDouble(request.getParameter("width"));
                double height = Double.parseDouble(request.getParameter("height"));
                String designation = request.getParameter("designation");
                Product p = Product.getById(idproduct);
                p.setSize(new Size(-1, length, width, height, designation));
                p.saveSize();
                break;
            case "matiere_prix":
                double quantity = Double.parseDouble(request.getParameter("quantity"));
                double price = Double.parseDouble(request.getParameter("price"));
                
                break;
            default:
                throw new AssertionError();
        }
           
        }catch(Exception e){
            e.printStackTrace(response.getWriter());
        }
        
//        response.sendRedirect("view/home.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
