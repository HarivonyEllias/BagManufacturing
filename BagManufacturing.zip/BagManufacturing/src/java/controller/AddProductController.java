/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import databaseconnection.PGSQLConnection;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Article;
import model.Material;
import model.Product;
import model.Type;

/**
 *
 * @author hariv
 */
public class AddProductController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int article = Integer.parseInt(request.getParameter("article"));
        String[] composantValues = request.getParameterValues("composant");
        int type = Integer.parseInt(request.getParameter("type"));
        String beginDate = request.getParameter("beginDate");
        String endDate = request.getParameter("endDate");

//        INSERT COMPOSANT =================================
//        PREPARE QUERY
        List<Material> lm = new ArrayList<>();
        for(String id : composantValues){
            try {
                lm.add( Material.getById(Integer.parseInt(id)) );
            } catch (Exception ex) {
                ex.printStackTrace(out);
            }
        }
        Connection connection = null;
        try {
//            TRANSACTIONNAL ACTION
            connection = PGSQLConnection.getConnection();
            connection.setAutoCommit(false);
            int ref = Material.createComposants(lm.toArray(new Material[lm.size()]), connection);
            Product product = new Product();
            product.setId(Product.getnextId());
            product.setArticle(Article.getById(article));
            product.setComponentRef(ref);
            product.setType(Type.getById(type));
            product.setBeginDate(beginDate);
            product.setEndDate(endDate);
            
            product.create(connection);
            connection.commit();
        } catch (Exception ex) {
            ex.printStackTrace(out);
            try {
                connection.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(AddProductController.class.getName()).log(Level.SEVERE, null, ex1);
            }
        } finally {
            try {
                connection.close();
            } catch (SQLException ex) {
                Logger.getLogger(AddProductController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        response.sendRedirect("view/home.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
