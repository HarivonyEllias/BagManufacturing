package databaseconnection;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Calendar;

public class PGSQLConnection implements Serializable{

    private static final long serialVersionUID = 1L;
    private static final String JDBC_URL = "jdbc:postgresql://localhost:5432/poketra";
    private static final String JDBC_USER = "postgres";
    private static final String JDBC_PASSWORD = "postgres";

    static {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("PostgreSQL JDBC driver not found. Make sure it's in your classpath.", e);
        }
    }
    
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
    }
    
    public static String getDayOfWeekFromDate(Date sqlDate) {
        // Convert java.sql.Date to java.util.Calendar
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(sqlDate);

        // Get the day of the week as an integer (Sunday = 1, Monday = 2, ..., Saturday = 7)
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);

        // Map integer value to the corresponding day name
        String dayName = "";
        switch (dayOfWeek) {
            case Calendar.SUNDAY:
                dayName = "sunday";
                break;
            case Calendar.MONDAY:
                dayName = "monday";
                break;
            case Calendar.TUESDAY:
                dayName = "tuesday";
                break;
            case Calendar.WEDNESDAY:
                dayName = "wednesday";
                break;
            case Calendar.THURSDAY:
                dayName = "thursday";
                break;
            case Calendar.FRIDAY:
                dayName = "friday";
                break;
            case Calendar.SATURDAY:
                dayName = "saturday";
                break;
        }

        return dayName;
    }
}
